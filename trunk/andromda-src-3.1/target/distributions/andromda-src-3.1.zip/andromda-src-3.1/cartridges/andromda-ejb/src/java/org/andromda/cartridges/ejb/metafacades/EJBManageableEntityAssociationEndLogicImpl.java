package org.andromda.cartridges.ejb.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.ejb.metafacades.EJBManageableEntityAssociationEnd.
 *
 * @see org.andromda.cartridges.ejb.metafacades.EJBManageableEntityAssociationEnd
 */
public class EJBManageableEntityAssociationEndLogicImpl
    extends EJBManageableEntityAssociationEndLogic
{

    public EJBManageableEntityAssociationEndLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.cartridges.ejb.metafacades.EJBManageableEntityAssociationEnd#getAlexandreAssociation()
     */
    protected java.lang.String handleGetAlexandreAssociation()
    {
        // TODO: put your implementation here.
        return null;
    }

}