package org.andromda.cartridges.ejb.metafacades;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.ejb.metafacades.EJBManageableEntity.
 *
 * @see org.andromda.cartridges.ejb.metafacades.EJBManageableEntity
 */
public class EJBManageableEntityLogicImpl
    extends EJBManageableEntityLogic
{

    public EJBManageableEntityLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.cartridges.ejb.metafacades.EJBManageableEntity#getAlexandre()
     */
    protected java.lang.String handleGetAlexandre()
    {
        // TODO: put your implementation here.
        return null;
    }

}