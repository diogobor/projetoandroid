package org.andromda.core.metafacade;


/**
 * Fake mapping object 9 (just used for testing the MetafacadeMappings).
 *
 * @author Chad Brandon
 */
public class MappingObject9
{
}