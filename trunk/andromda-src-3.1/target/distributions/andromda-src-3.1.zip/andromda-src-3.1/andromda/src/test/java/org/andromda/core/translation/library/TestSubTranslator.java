package org.andromda.core.translation.library;


/**
 * A Test Translator
 *
 * @author Chad Brandon
 */
public class TestSubTranslator
    extends TestTranslator
{
}